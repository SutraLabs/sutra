"""Sutra package public API."""

from .core import (
    Trace,
    Agent,
    Step,
    Pipeline,
    Ollama,
    get_available_models,
    cmd_create,
    cmd_run,
    cmd_test,
    cmd_doctor,
    cmd_template,
    cmd_ui,
)

__all__ = [
    "__version__",
    "Trace",
    "Agent",
    "Step",
    "Pipeline",
    "Ollama",
    "get_available_models",
    "cmd_create",
    "cmd_run",
    "cmd_test",
    "cmd_doctor",
    "cmd_template",
    "cmd_ui",
]

__version__ = "0.1.0"
